# Coding Lab XX: Title

## Related Course Module

## Related Practice Module

## Related Weiss Topic

## Learning Objectives

## Files in This Lab

## How to Compile

```bash
javac *.java
```

## How to Run

```bash
java ExampleDemo
```

## Student Tasks

## Complexity and Design Questions

## Expected Takeaways
