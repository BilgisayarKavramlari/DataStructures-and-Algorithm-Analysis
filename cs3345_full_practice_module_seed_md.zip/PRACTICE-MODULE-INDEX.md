# Practice Module Index

| Course Module | Coding Lab | Practice Module | Topic | Main Demo |
|---|---|---|---|---|
| Module 0 | `lab-00-repository-codespaces-setup` | `practice-module-00-repository-codespaces-setup` | Repository and Codespaces Setup | `PracticeModule00Demo.java` |
| Module 0 / Module 1 | `lab-01-java-review` | `practice-module-01-java-review` | Java Review | `PracticeModule01Demo.java` |
| Module 1 / Module 2 | `lab-02-adt-linear-structures-review` | `practice-module-02-adt-linear-structures-review` | ADTs and Linear Structures | `PracticeModule02Demo.java` |
| Module 1 / Module 2 | `lab-03-java-collections` | `practice-module-03-java-collections` | Java Collections | `PracticeModule03Demo.java` |
| Module 1 | `lab-04-growth-rates` | `practice-module-04-growth-rates` | Growth Rates | `PracticeModule04Demo.java` |
| Module 2 | `lab-05-recursion-factorial-fibonacci` | `practice-module-05-recursion-factorial-fibonacci` | Recursion, Factorial, and Fibonacci | `PracticeModule05Demo.java` |
| Module 2 | `lab-06-maximum-subsequence-sum` | `practice-module-06-maximum-subsequence-sum` | Maximum Subsequence Sum | `PracticeModule06Demo.java` |
| Module 1 / Module 2 | `lab-07-formal-algorithm-analysis` | `practice-module-07-formal-algorithm-analysis` | Formal Algorithm Analysis | `PracticeModule07Demo.java` |
| Module 3 | `lab-08-tree-basics-traversals` | `practice-module-08-tree-basics-traversals` | Tree Basics and Traversals | `PracticeModule08Demo.java` |
| Module 3 | `lab-09-expression-trees` | `practice-module-09-expression-trees` | Expression Trees | `PracticeModule09Demo.java` |
| Module 3 | `lab-10-binary-search-trees` | `practice-module-10-binary-search-trees` | Binary Search Trees | `PracticeModule10Demo.java` |
| Module 4 | `lab-11-avl-trees-rotations` | `practice-module-11-avl-trees-rotations` | AVL Trees and Rotations | `PracticeModule11Demo.java` |
| Module 4 | `lab-12-splay-trees` | `practice-module-12-splay-trees` | Splay Trees | `PracticeModule12Demo.java` |
| Module 4 | `lab-13-red-black-and-2-4-trees` | `practice-module-13-red-black-and-2-4-trees` | Red-Black Trees and 2-4 Trees | `PracticeModule13Demo.java` |
| Module 4 | `lab-14-b-trees-multiway-search` | `practice-module-14-b-trees-multiway-search` | B-Trees and Multi-Way Search | `PracticeModule14Demo.java` |
| Module 4 | `lab-15-java-ordered-collections` | `practice-module-15-java-ordered-collections` | Java Ordered Collections | `PracticeModule15Demo.java` |
| Module 5 | `lab-16-binary-heap-priority-queue` | `practice-module-16-binary-heap-priority-queue` | Binary Heap and Priority Queue | `PracticeModule16Demo.java` |
| Module 5 | `lab-17-sorting-algorithms` | `practice-module-17-sorting-algorithms` | Sorting Algorithms | `PracticeModule17Demo.java` |
| Module 6 | `lab-18-hash-tables` | `practice-module-18-hash-tables` | Hash Tables | `PracticeModule18Demo.java` |
| Module 6 | `lab-19-amortized-analysis` | `practice-module-19-amortized-analysis` | Amortized Analysis | `PracticeModule19Demo.java` |
| Module 7 | `lab-20-graph-representations` | `practice-module-20-graph-representations` | Graph Representations | `PracticeModule20Demo.java` |
| Module 7 | `lab-21-bfs-dfs-topological-sort` | `practice-module-21-bfs-dfs-topological-sort` | BFS, DFS, Connected Components, and Topological Sort | `PracticeModule21Demo.java` |
| Module 8 | `lab-22-shortest-paths-dijkstra` | `practice-module-22-shortest-paths-dijkstra` | Shortest Paths and Dijkstra | `PracticeModule22Demo.java` |
| Module 9 | `lab-23-disjoint-sets-union-find` | `practice-module-23-disjoint-sets-union-find` | Disjoint Sets and Union-Find | `PracticeModule23Demo.java` |
| Module 9 | `lab-24-minimum-spanning-trees` | `practice-module-24-minimum-spanning-trees` | Minimum Spanning Trees | `PracticeModule24Demo.java` |
| Module 10 | `lab-25-algorithm-design-techniques` | `practice-module-25-algorithm-design-techniques` | Algorithm Design Techniques | `PracticeModule25Demo.java` |
| Module 10 | `lab-26-data-structure-selection` | `practice-module-26-data-structure-selection` | Advanced Data Structure Selection and Applications | `PracticeModule26Demo.java` |
| Module 11 | `lab-27-final-review-synthesis` | `practice-module-27-final-review-synthesis` | Final Review Synthesis | `PracticeModule27Demo.java` |
