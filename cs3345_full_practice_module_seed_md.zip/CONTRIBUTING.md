# Contributing and Workflow

## Student Workflow

1. Fork the repository.
2. Open the fork in Codespaces.
3. Navigate to a Coding Lab or Practice Module.
4. Compile and run Java files.
5. Modify examples for practice.
6. Commit to your own fork.

## Running a Practice Module

```bash
cd practice-module-10-binary-search-trees
javac *.java
java PracticeModule10Demo
```

## Instructor Validation

```bash
bash scripts/compile-all.sh
```
