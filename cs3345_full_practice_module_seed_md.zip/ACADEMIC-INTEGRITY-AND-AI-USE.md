# Academic Integrity and AI Use

The repository supports learning, tracing, practice, and review.

Students may use examples to study concepts, but graded work must follow the syllabus, eLearning instructions, and instructor announcements.

Students should be able to explain:

- what the code does,
- why the invariant holds,
- how operations change the structure,
- time complexity,
- space complexity,
- edge cases,
- design tradeoffs.

AI tools may be used for study when allowed, but students remain responsible for understanding and authorship.
