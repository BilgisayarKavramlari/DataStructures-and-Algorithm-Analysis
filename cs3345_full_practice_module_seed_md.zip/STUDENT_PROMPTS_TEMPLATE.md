# Student Prompts for Practice Module XX

## Prediction Questions

1. What will happen next?
2. Which node, index, or item will be visited next?
3. What will the output be?

## Trace Questions

1. Trace this operation by hand.
2. Which reference, color, array cell, or distance changes?
3. What is the structure after one more step?

## Invariant Questions

1. What invariant must remain true?
2. Which line restores the invariant?
3. What breaks if this invariant is violated?

## Complexity Questions

1. What is the best case?
2. What is the worst case?
3. What input causes the worst case?
4. What is the space complexity?

## Design Questions

1. Why use this structure instead of an alternative?
2. Which operation is optimized?
3. What tradeoff is being made?

## Edge-Case Questions

1. What happens with empty input?
2. What happens with one item?
3. What happens with duplicates?
4. What happens with sorted input?

## Extension Challenges

1. Add an invariant checker.
2. Add a timing experiment.
3. Add a new edge-case test.
