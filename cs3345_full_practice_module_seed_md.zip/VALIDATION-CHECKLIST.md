# Validation Checklist

## Root Checks

- [ ] Required root Markdown files exist.
- [ ] `.gitignore` exists.
- [ ] `scripts/compile-all.sh` exists.
- [ ] `scripts/run-practice-module.sh` exists.

## Practice Module Checks

For every `practice-module-XX-*` folder:

- [ ] `README.md`
- [ ] `RUN_ORDER.md`
- [ ] `EXPECTED_OUTPUT.md`
- [ ] `INSTRUCTOR_NOTES.md`
- [ ] `STUDENT_PROMPTS.md`
- [ ] `PracticeModuleXXDemo.java`
- [ ] Compiles with `javac *.java`
- [ ] Runs with meaningful output
- [ ] Not a placeholder

## Advanced Topic Checks

- [ ] Red-black trees
- [ ] Splay trees
- [ ] B-trees
- [ ] Leftist heaps
- [ ] Skew heaps
- [ ] Binomial queues
- [ ] Advanced hashing demos
- [ ] Amortized analysis
- [ ] Dijkstra
- [ ] Union-find
- [ ] Prim and Kruskal
- [ ] Algorithm design examples

## Compile

```bash
bash scripts/compile-all.sh
```
