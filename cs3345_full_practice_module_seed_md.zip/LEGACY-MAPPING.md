# Legacy Mapping

Older GitHub practice folders may have used `module-*`.

Use the new naming:

| Old | New Student Folder | New Instructor Folder |
|---|---|---|
| `module-XX-topic` | `lab-XX-topic` | `practice-module-XX-topic` |

The eLearning theory units remain **Course Modules**.
