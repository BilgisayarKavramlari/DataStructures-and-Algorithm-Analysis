# Wednesday Practice Teaching Guide

## Goal

Use Practice Modules to make theory visible through runnable Java code.

## Standard Flow

1. Open the relevant `practice-module-XX-*` folder.
2. Read `RUN_ORDER.md`.
3. Open `PracticeModuleXXDemo.java`.
4. Explain the invariant or algorithmic idea.
5. Ask students to predict output.
6. Compile with `javac *.java`.
7. Run the demo.
8. Compare output with predictions.
9. Open implementation files.
10. Discuss complexity, edge cases, and design tradeoffs.
11. Use `STUDENT_PROMPTS.md` for questions.

## Instructor Checklist Before Class

- Does the folder compile?
- Does the demo run?
- Does output show a useful trace?
- Are simplifications documented?
- Are there meaningful student prompts?
