# Copyright and Source Use

The repository may refer to textbook chapter topics, but it must not copy protected content.

Do not commit:

- textbook PDFs,
- slide decks,
- textbook images,
- scanned pages,
- copied textbook source code,
- instructor-only solutions.

Allowed:

- original Java implementations,
- original explanations,
- original trace examples,
- topic references,
- educational simplifications.

Advanced topics may be simplified if clearly documented.
