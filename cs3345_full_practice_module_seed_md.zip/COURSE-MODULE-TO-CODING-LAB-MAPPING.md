# Course Module to Coding Lab and Practice Module Mapping

| Course Module | Coding Lab | Practice Module | Topic |
|---|---|---|---|
| Module 0 | `lab-00-repository-codespaces-setup` | `practice-module-00-repository-codespaces-setup` | Repository and Codespaces Setup |
| Module 0 / Module 1 | `lab-01-java-review` | `practice-module-01-java-review` | Java Review |
| Module 1 / Module 2 | `lab-02-adt-linear-structures-review` | `practice-module-02-adt-linear-structures-review` | ADTs and Linear Structures |
| Module 1 / Module 2 | `lab-03-java-collections` | `practice-module-03-java-collections` | Java Collections |
| Module 1 | `lab-04-growth-rates` | `practice-module-04-growth-rates` | Growth Rates |
| Module 2 | `lab-05-recursion-factorial-fibonacci` | `practice-module-05-recursion-factorial-fibonacci` | Recursion, Factorial, and Fibonacci |
| Module 2 | `lab-06-maximum-subsequence-sum` | `practice-module-06-maximum-subsequence-sum` | Maximum Subsequence Sum |
| Module 1 / Module 2 | `lab-07-formal-algorithm-analysis` | `practice-module-07-formal-algorithm-analysis` | Formal Algorithm Analysis |
| Module 3 | `lab-08-tree-basics-traversals` | `practice-module-08-tree-basics-traversals` | Tree Basics and Traversals |
| Module 3 | `lab-09-expression-trees` | `practice-module-09-expression-trees` | Expression Trees |
| Module 3 | `lab-10-binary-search-trees` | `practice-module-10-binary-search-trees` | Binary Search Trees |
| Module 4 | `lab-11-avl-trees-rotations` | `practice-module-11-avl-trees-rotations` | AVL Trees and Rotations |
| Module 4 | `lab-12-splay-trees` | `practice-module-12-splay-trees` | Splay Trees |
| Module 4 | `lab-13-red-black-and-2-4-trees` | `practice-module-13-red-black-and-2-4-trees` | Red-Black Trees and 2-4 Trees |
| Module 4 | `lab-14-b-trees-multiway-search` | `practice-module-14-b-trees-multiway-search` | B-Trees and Multi-Way Search |
| Module 4 | `lab-15-java-ordered-collections` | `practice-module-15-java-ordered-collections` | Java Ordered Collections |
| Module 5 | `lab-16-binary-heap-priority-queue` | `practice-module-16-binary-heap-priority-queue` | Binary Heap and Priority Queue |
| Module 5 | `lab-17-sorting-algorithms` | `practice-module-17-sorting-algorithms` | Sorting Algorithms |
| Module 6 | `lab-18-hash-tables` | `practice-module-18-hash-tables` | Hash Tables |
| Module 6 | `lab-19-amortized-analysis` | `practice-module-19-amortized-analysis` | Amortized Analysis |
| Module 7 | `lab-20-graph-representations` | `practice-module-20-graph-representations` | Graph Representations |
| Module 7 | `lab-21-bfs-dfs-topological-sort` | `practice-module-21-bfs-dfs-topological-sort` | BFS, DFS, Connected Components, and Topological Sort |
| Module 8 | `lab-22-shortest-paths-dijkstra` | `practice-module-22-shortest-paths-dijkstra` | Shortest Paths and Dijkstra |
| Module 9 | `lab-23-disjoint-sets-union-find` | `practice-module-23-disjoint-sets-union-find` | Disjoint Sets and Union-Find |
| Module 9 | `lab-24-minimum-spanning-trees` | `practice-module-24-minimum-spanning-trees` | Minimum Spanning Trees |
| Module 10 | `lab-25-algorithm-design-techniques` | `practice-module-25-algorithm-design-techniques` | Algorithm Design Techniques |
| Module 10 | `lab-26-data-structure-selection` | `practice-module-26-data-structure-selection` | Advanced Data Structure Selection and Applications |
| Module 11 | `lab-27-final-review-synthesis` | `practice-module-27-final-review-synthesis` | Final Review Synthesis |
