# Practice Module Requirements

Practice Modules are instructor-facing, lecture-ready folders.

## Required Files in Every Practice Module

```text
README.md
RUN_ORDER.md
EXPECTED_OUTPUT.md
INSTRUCTOR_NOTES.md
STUDENT_PROMPTS.md
PracticeModuleXXDemo.java
```

## README.md Must Include

- Practice Module number and title
- Related Course Module
- Related Coding Lab
- Related Weiss chapter/topic
- Theory topics covered
- Implementation topics covered
- Java file list
- Compile and run commands
- Instructor teaching flow
- Data structure invariants
- Complexity summary
- Edge cases
- Expected takeaways
- Intentional simplifications

## RUN_ORDER.md Must Include

- file-opening order
- compile command
- run command
- teaching sequence
- checkpoints for student prediction

## EXPECTED_OUTPUT.md Must Include

- representative terminal output
- notes about randomized output if applicable

## INSTRUCTOR_NOTES.md Must Include

- teaching emphasis
- common confusions
- board/tablet sketches
- live coding suggestions
- complexity discussion
- simplification notes

## STUDENT_PROMPTS.md Must Include

- prediction questions
- trace questions
- invariant questions
- complexity questions
- edge-case questions
- extension challenges

## Java Quality

- No placeholders.
- No TODO-only files.
- No packages.
- No external dependencies.
- Must compile.
- Must run.
- Must be suitable for live teaching.
