# AGENTS.md

## Project

This repository supports CS 3345 live teaching and student practice.

## Terminology

Use these terms exactly:

- **Course Module**: official eLearning/theory unit.
- **Coding Lab**: student-facing GitHub practice folder named `lab-XX-topic`.
- **Practice Module**: instructor-facing lecture-ready folder named `practice-module-XX-topic`.

Do not call GitHub folders simply "modules."

## Language

All repository files must be in English.

## Copyright

Do not copy textbook pages, slide content, images, diagrams, or protected source code into the repository. Create original educational Java code and explanations.

## Java Rules

- Plain Java only.
- No packages.
- No Maven or Gradle.
- No external libraries.
- Use only Java standard library.
- Every Practice Module must compile with `javac *.java`.
- Every Practice Module must include a runnable main class.
- Prefer `PracticeModuleXXDemo.java`.

## Required Files in Every Practice Module

```text
README.md
RUN_ORDER.md
EXPECTED_OUTPUT.md
INSTRUCTOR_NOTES.md
STUDENT_PROMPTS.md
PracticeModuleXXDemo.java
```

Do not create placeholder-only modules. The code must be runnable and teachable.

## Required Practice Modules

- `practice-module-00-repository-codespaces-setup`
- `practice-module-01-java-review`
- `practice-module-02-adt-linear-structures-review`
- `practice-module-03-java-collections`
- `practice-module-04-growth-rates`
- `practice-module-05-recursion-factorial-fibonacci`
- `practice-module-06-maximum-subsequence-sum`
- `practice-module-07-formal-algorithm-analysis`
- `practice-module-08-tree-basics-traversals`
- `practice-module-09-expression-trees`
- `practice-module-10-binary-search-trees`
- `practice-module-11-avl-trees-rotations`
- `practice-module-12-splay-trees`
- `practice-module-13-red-black-and-2-4-trees`
- `practice-module-14-b-trees-multiway-search`
- `practice-module-15-java-ordered-collections`
- `practice-module-16-binary-heap-priority-queue`
- `practice-module-17-sorting-algorithms`
- `practice-module-18-hash-tables`
- `practice-module-19-amortized-analysis`
- `practice-module-20-graph-representations`
- `practice-module-21-bfs-dfs-topological-sort`
- `practice-module-22-shortest-paths-dijkstra`
- `practice-module-23-disjoint-sets-union-find`
- `practice-module-24-minimum-spanning-trees`
- `practice-module-25-algorithm-design-techniques`
- `practice-module-26-data-structure-selection`
- `practice-module-27-final-review-synthesis`

## Validation

Run:

```bash
bash scripts/compile-all.sh
```

Fix all compilation errors before finishing.
