# Codex One-Shot Prompt

Copy and paste the prompt below into Codex.

## Prompt

You are working on `BilgisayarKavramlari/DataStructures-and-Algorithm-Analysis`.

Read all root Markdown files first, especially `AGENTS.md`, `IMPLEMENTATION-SPEC.md`, `PRACTICE-MODULE-REQUIREMENTS.md`, `PRACTICE-MODULE-INDEX.md`, and all template files.

Rebuild and complete the repository as a full CS 3345 Java instructional codebase.

Keep any existing `lab-*` folders. Create or complete matching `practice-module-*` folders.

The `lab-*` folders are student-facing. The `practice-module-*` folders are instructor-facing and must contain complete lecture-ready Java code.

## Critical Requirements

1. All content must be in English.
2. Use plain Java only.
3. Do not use packages.
4. Do not use Maven, Gradle, or external libraries.
5. Do not copy textbook or slide content into the repository.
6. Every Practice Module must compile with `javac *.java`.
7. Every Practice Module must include `PracticeModuleXXDemo.java` or a clearly named main driver.
8. Every Practice Module must include `README.md`, `RUN_ORDER.md`, `EXPECTED_OUTPUT.md`, `INSTRUCTOR_NOTES.md`, and `STUDENT_PROMPTS.md`.
9. Do not create placeholder-only modules.
10. Do not stop after scaffolding.
11. Generate complete runnable educational code with trace output suitable for live Wednesday teaching.

## Create Student-Facing Coding Labs

- `lab-00-repository-codespaces-setup`
- `lab-01-java-review`
- `lab-02-adt-linear-structures-review`
- `lab-03-java-collections`
- `lab-04-growth-rates`
- `lab-05-recursion-factorial-fibonacci`
- `lab-06-maximum-subsequence-sum`
- `lab-07-formal-algorithm-analysis`
- `lab-08-tree-basics-traversals`
- `lab-09-expression-trees`
- `lab-10-binary-search-trees`
- `lab-11-avl-trees-rotations`
- `lab-12-splay-trees`
- `lab-13-red-black-and-2-4-trees`
- `lab-14-b-trees-multiway-search`
- `lab-15-java-ordered-collections`
- `lab-16-binary-heap-priority-queue`
- `lab-17-sorting-algorithms`
- `lab-18-hash-tables`
- `lab-19-amortized-analysis`
- `lab-20-graph-representations`
- `lab-21-bfs-dfs-topological-sort`
- `lab-22-shortest-paths-dijkstra`
- `lab-23-disjoint-sets-union-find`
- `lab-24-minimum-spanning-trees`
- `lab-25-algorithm-design-techniques`
- `lab-26-data-structure-selection`
- `lab-27-final-review-synthesis`

## Create Instructor-Facing Practice Modules

- `practice-module-00-repository-codespaces-setup`
- `practice-module-01-java-review`
- `practice-module-02-adt-linear-structures-review`
- `practice-module-03-java-collections`
- `practice-module-04-growth-rates`
- `practice-module-05-recursion-factorial-fibonacci`
- `practice-module-06-maximum-subsequence-sum`
- `practice-module-07-formal-algorithm-analysis`
- `practice-module-08-tree-basics-traversals`
- `practice-module-09-expression-trees`
- `practice-module-10-binary-search-trees`
- `practice-module-11-avl-trees-rotations`
- `practice-module-12-splay-trees`
- `practice-module-13-red-black-and-2-4-trees`
- `practice-module-14-b-trees-multiway-search`
- `practice-module-15-java-ordered-collections`
- `practice-module-16-binary-heap-priority-queue`
- `practice-module-17-sorting-algorithms`
- `practice-module-18-hash-tables`
- `practice-module-19-amortized-analysis`
- `practice-module-20-graph-representations`
- `practice-module-21-bfs-dfs-topological-sort`
- `practice-module-22-shortest-paths-dijkstra`
- `practice-module-23-disjoint-sets-union-find`
- `practice-module-24-minimum-spanning-trees`
- `practice-module-25-algorithm-design-techniques`
- `practice-module-26-data-structure-selection`
- `practice-module-27-final-review-synthesis`

## Required Practice Module Coverage

- Practice Module 00 `repository-codespaces-setup`: GitHub, Codespaces, javac/java workflow. Required examples include: PracticeModule00Demo.java, HelloCS3345.java, CodespacesCheck.java.
- Practice Module 01 `java-review`: Java syntax, arrays, objects, generics, Comparable, Comparator. Required examples include: PracticeModule01Demo.java, VariablesAndTypesDemo.java, ArraysAndReferencesDemo.java, ComparableComparatorIntroDemo.java.
- Practice Module 02 `adt-linear-structures-review`: ADT, List, array list, linked list, stack, queue, deque, iterator, ConcurrentModificationException. Required examples include: PracticeModule02Demo.java, ArrayBasedList.java, SinglyLinkedList.java, DoublyLinkedList.java, ArrayStack.java, LinkedQueue.java.
- Practice Module 03 `java-collections`: Collection, Iterable, Iterator, List, Set, Map, Queue, Deque, PriorityQueue. Required examples include: PracticeModule03Demo.java, CollectionInterfaceDemo.java, IteratorRemoveDemo.java, ListArrayListLinkedListDemo.java, SetDemo.java, MapDemo.java.
- Practice Module 04 `growth-rates`: O(1), O(log n), O(n), O(n log n), O(n^2), O(n^3), exponential, factorial, empirical timing. Required examples include: PracticeModule04Demo.java, ConstantGrowthDemo.java, LogarithmicGrowthDemo.java, QuadraticGrowthDemo.java, TimingExperiment.java.
- Practice Module 05 `recursion-factorial-fibonacci`: base case, progress, call stack, recursive print, factorial, Fibonacci, memoization. Required examples include: PracticeModule05Demo.java, RecursivePrintDemo.java, FactorialRecursive.java, FibonacciNaiveRecursive.java, FibonacciMemoized.java.
- Practice Module 06 `maximum-subsequence-sum`: cubic, quadratic, divide-and-conquer, linear Kadane algorithm, timing comparison. Required examples include: PracticeModule06Demo.java, MaxSubsequenceCubic.java, MaxSubsequenceQuadratic.java, MaxSubsequenceDivideConquer.java, MaxSubsequenceLinear.java.
- Practice Module 07 `formal-algorithm-analysis`: Big-O, Big-Omega, Big-Theta, little-o, little-omega, loop counting, recurrences, space complexity. Required examples include: PracticeModule07Demo.java, BigONotationExamples.java, LoopCountingDemo.java, RecurrenceTraceDemo.java, SpaceComplexityDemo.java.
- Practice Module 08 `tree-basics-traversals`: tree terminology, first-child/next-sibling, binary trees, preorder, inorder, postorder, level-order, directory size. Required examples include: PracticeModule08Demo.java, GeneralTreeNode.java, FirstChildNextSiblingDemo.java, BinaryTreeTraversalDemo.java, DirectoryTreeDemo.java.
- Practice Module 09 `expression-trees`: postfix construction, stack-based expression tree, prefix/infix/postfix traversal, evaluation. Required examples include: PracticeModule09Demo.java, ExpressionTreeNode.java, PostfixExpressionTreeBuilder.java, ExpressionTreeEvaluator.java.
- Practice Module 10 `binary-search-trees`: BST invariant, contains, findMin, findMax, insert, remove, height, predecessor, successor, invariant checker. Required examples include: PracticeModule10Demo.java, BinarySearchTree.java, BSTDeleteDemo.java, BSTHeightExperiment.java, BSTInvariantChecker.java.
- Practice Module 11 `avl-trees-rotations`: height balance, LL, RR, LR, RL rotations, insertion, deletion concept, AVL vs BST. Required examples include: PracticeModule11Demo.java, AVLTree.java, AVLRotationTraceDemo.java, AVLInvariantChecker.java, AVLvsBSTExperiment.java.
- Practice Module 12 `splay-trees`: zig, zig-zig, zig-zag, splaying after access, locality, amortized intuition. Required examples include: PracticeModule12Demo.java, SplayTree.java, ZigDemo.java, ZigZigDemo.java, ZigZagDemo.java, SplayAccessTraceDemo.java.
- Practice Module 13 `red-black-and-2-4-trees`: red-black invariants, recoloring, rotations, insertion trace, deletion concepts, 2-4 tree correspondence. Required examples include: PracticeModule13Demo.java, RedBlackTreeEducational.java, RedBlackInvariantChecker.java, RedBlackInsertionTraceDemo.java, TwoFourTreeTraceDemo.java.
- Practice Module 14 `b-trees-multiway-search`: multi-way search, B-tree search/insertion, split, median promotion, root/internal split, deletion concept. Required examples include: PracticeModule14Demo.java, BTreeEducational.java, BTreeSearchDemo.java, BTreeInsertionTraceDemo.java, BTreeSplitDemo.java.
- Practice Module 15 `java-ordered-collections`: TreeSet, TreeMap, SortedSet, NavigableSet, NavigableMap, Comparable, Comparator, ordering pitfalls. Required examples include: PracticeModule15Demo.java, ComparableStudentDemo.java, TreeSetDemo.java, TreeMapDemo.java, OrderingPitfallsDemo.java.
- Practice Module 16 `binary-heap-priority-queue`: binary heap, percolate up/down, buildHeap, decreaseKey, increaseKey, selection, event simulation, d-heap, leftist/skew/binomial heaps. Required examples include: PracticeModule16Demo.java, BinaryMinHeap.java, BuildHeapDemo.java, SelectionProblemHeapDemo.java, LeftistHeapEducational.java, SkewHeapEducational.java.
- Practice Module 17 `sorting-algorithms`: insertion sort, shellsort, heapsort, mergesort, quicksort, quickselect, radix/bucket intro, stability, lower bound intuition. Required examples include: PracticeModule17Demo.java, InsertionSort.java, ShellSort.java, HeapSort.java, MergeSort.java, QuickSort.java, QuickSelect.java, SortingTimingComparison.java.
- Practice Module 18 `hash-tables`: hash functions, separate chaining, linear/quadratic probing, double hashing, lazy deletion, load factor, rehashing, advanced hashing demos. Required examples include: PracticeModule18Demo.java, SeparateChainingHashTable.java, LinearProbingHashTable.java, QuadraticProbingHashTable.java, RehashingDemo.java, CuckooHashingEducationalDemo.java.
- Practice Module 19 `amortized-analysis`: dynamic array resizing, table doubling, aggregate/accounting/potential intuition, rehashing, splay/binomial/skew/Fibonacci intuition. Required examples include: PracticeModule19Demo.java, DynamicArray.java, DynamicArrayResizeTraceDemo.java, AggregateAnalysisDemo.java, FibonacciHeapConceptDemo.java.
- Practice Module 20 `graph-representations`: directed/undirected/weighted graphs, adjacency matrix, adjacency list, edge list, degree, sparse/dense tradeoff. Required examples include: PracticeModule20Demo.java, AdjacencyListGraph.java, AdjacencyMatrixGraph.java, EdgeListGraph.java, SparseDenseGraphComparison.java.
- Practice Module 21 `bfs-dfs-topological-sort`: BFS, DFS recursive/iterative, connected components, cycle detection, topological sort by scan and queue. Required examples include: PracticeModule21Demo.java, BFS.java, DFSRecursive.java, ConnectedComponents.java, TopologicalSortQueue.java.
- Practice Module 22 `shortest-paths-dijkstra`: unweighted shortest path, Dijkstra with/without priority queue, relaxation, path reconstruction, negative edge limitation, DAG/all-pairs demo. Required examples include: PracticeModule22Demo.java, UnweightedShortestPathBFS.java, DijkstraWithPriorityQueue.java, RelaxationTraceDemo.java, NegativeEdgeCounterexample.java.
- Practice Module 23 `disjoint-sets-union-find`: quick-find, quick-union, union by size/rank, path compression, equivalence classes, maze generation. Required examples include: PracticeModule23Demo.java, QuickFind.java, QuickUnion.java, UnionByRank.java, PathCompressionDemo.java, MazeGenerationDemo.java.
- Practice Module 24 `minimum-spanning-trees`: Prim, Kruskal, priority queue integration, union-find integration, MST trace, disconnected graph handling. Required examples include: PracticeModule24Demo.java, PrimMST.java, KruskalMST.java, MSTTraceDemo.java, MSTvsShortestPathDemo.java.
- Practice Module 25 `algorithm-design-techniques`: greedy, Huffman, bin packing, divide and conquer, selection, dynamic programming, randomized algorithms, backtracking, skip list concept. Required examples include: PracticeModule25Demo.java, GreedySchedulingDemo.java, HuffmanCodingDemo.java, DynamicProgrammingFibonacciDemo.java, BacktrackingSubsetsDemo.java.
- Practice Module 26 `data-structure-selection`: data structure selection, operation tradeoffs, treap, suffix-array-style string index, k-d tree simplified range search, pairing heap demo. Required examples include: PracticeModule26Demo.java, DataStructureSelectionCases.java, OperationCostComparison.java, TreapEducationalDemo.java, KDTreeSimplifiedRangeSearchDemo.java.
- Practice Module 27 `final-review-synthesis`: cumulative tracing, complexity classification, data structure selection, trees/heaps/hashing/sorting/graphs review. Required examples include: PracticeModule27Demo.java, CumulativeTraceDemo.java, ComplexityClassificationReview.java, FinalExamStylePractice.java.

## Advanced Topics Must Not Be Omitted

Include runnable educational demos for red-black trees, splay trees, B-trees, 2-4 trees, leftist heaps, skew heaps, binomial queues, cuckoo/hopscotch/universal/extendible hashing, amortized analysis, graph algorithms, Dijkstra, union-find, Prim, Kruskal, dynamic programming, randomized algorithms, skip list concept, treap, suffix-array-style string index, k-d tree simplified range search, and pairing heap concept.

Advanced implementations may be educationally simplified, but simplifications must be explained in `README.md` and `INSTRUCTOR_NOTES.md`.

## Root Files and Scripts

Create or update all root Markdown files and add:

```text
.gitignore
scripts/compile-all.sh
scripts/run-practice-module.sh
```

The compile script must compile all Java files in both `lab-*` and `practice-module-*` folders.

## Final Validation

Run:

```bash
bash scripts/compile-all.sh
```

Fix every compile error. Then commit all changes and report the created folders, major implementations, compile result, simplifications, and instructor review points.
