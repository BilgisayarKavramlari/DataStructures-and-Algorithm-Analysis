# Run Order for Practice Module XX

## Recommended File Opening Order

1. `README.md`
2. `PracticeModuleXXDemo.java`
3. Main implementation file
4. Trace demo file
5. `EXPECTED_OUTPUT.md`
6. `STUDENT_PROMPTS.md`

## Commands

```bash
javac *.java
java PracticeModuleXXDemo
```

## Teaching Checkpoints

- Ask students to predict output.
- Ask students to identify the invariant.
- Ask students to estimate complexity.
- Run an edge case.
