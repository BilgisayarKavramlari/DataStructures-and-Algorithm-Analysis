# Implementation Specification

## Practice Module 00: Repository and Codespaces Setup

Folder: `practice-module-00-repository-codespaces-setup`

Related Course Module: Module 0

Topics: GitHub, Codespaces, javac/java workflow

Required Java examples: PracticeModule00Demo.java, HelloCS3345.java, CodespacesCheck.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 01: Java Review

Folder: `practice-module-01-java-review`

Related Course Module: Module 0 / Module 1

Topics: Java syntax, arrays, objects, generics, Comparable, Comparator

Required Java examples: PracticeModule01Demo.java, VariablesAndTypesDemo.java, ArraysAndReferencesDemo.java, ComparableComparatorIntroDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 02: ADTs and Linear Structures

Folder: `practice-module-02-adt-linear-structures-review`

Related Course Module: Module 1 / Module 2

Topics: ADT, List, array list, linked list, stack, queue, deque, iterator, ConcurrentModificationException

Required Java examples: PracticeModule02Demo.java, ArrayBasedList.java, SinglyLinkedList.java, DoublyLinkedList.java, ArrayStack.java, LinkedQueue.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 03: Java Collections

Folder: `practice-module-03-java-collections`

Related Course Module: Module 1 / Module 2

Topics: Collection, Iterable, Iterator, List, Set, Map, Queue, Deque, PriorityQueue

Required Java examples: PracticeModule03Demo.java, CollectionInterfaceDemo.java, IteratorRemoveDemo.java, ListArrayListLinkedListDemo.java, SetDemo.java, MapDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 04: Growth Rates

Folder: `practice-module-04-growth-rates`

Related Course Module: Module 1

Topics: O(1), O(log n), O(n), O(n log n), O(n^2), O(n^3), exponential, factorial, empirical timing

Required Java examples: PracticeModule04Demo.java, ConstantGrowthDemo.java, LogarithmicGrowthDemo.java, QuadraticGrowthDemo.java, TimingExperiment.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 05: Recursion, Factorial, and Fibonacci

Folder: `practice-module-05-recursion-factorial-fibonacci`

Related Course Module: Module 2

Topics: base case, progress, call stack, recursive print, factorial, Fibonacci, memoization

Required Java examples: PracticeModule05Demo.java, RecursivePrintDemo.java, FactorialRecursive.java, FibonacciNaiveRecursive.java, FibonacciMemoized.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 06: Maximum Subsequence Sum

Folder: `practice-module-06-maximum-subsequence-sum`

Related Course Module: Module 2

Topics: cubic, quadratic, divide-and-conquer, linear Kadane algorithm, timing comparison

Required Java examples: PracticeModule06Demo.java, MaxSubsequenceCubic.java, MaxSubsequenceQuadratic.java, MaxSubsequenceDivideConquer.java, MaxSubsequenceLinear.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 07: Formal Algorithm Analysis

Folder: `practice-module-07-formal-algorithm-analysis`

Related Course Module: Module 1 / Module 2

Topics: Big-O, Big-Omega, Big-Theta, little-o, little-omega, loop counting, recurrences, space complexity

Required Java examples: PracticeModule07Demo.java, BigONotationExamples.java, LoopCountingDemo.java, RecurrenceTraceDemo.java, SpaceComplexityDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 08: Tree Basics and Traversals

Folder: `practice-module-08-tree-basics-traversals`

Related Course Module: Module 3

Topics: tree terminology, first-child/next-sibling, binary trees, preorder, inorder, postorder, level-order, directory size

Required Java examples: PracticeModule08Demo.java, GeneralTreeNode.java, FirstChildNextSiblingDemo.java, BinaryTreeTraversalDemo.java, DirectoryTreeDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 09: Expression Trees

Folder: `practice-module-09-expression-trees`

Related Course Module: Module 3

Topics: postfix construction, stack-based expression tree, prefix/infix/postfix traversal, evaluation

Required Java examples: PracticeModule09Demo.java, ExpressionTreeNode.java, PostfixExpressionTreeBuilder.java, ExpressionTreeEvaluator.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 10: Binary Search Trees

Folder: `practice-module-10-binary-search-trees`

Related Course Module: Module 3

Topics: BST invariant, contains, findMin, findMax, insert, remove, height, predecessor, successor, invariant checker

Required Java examples: PracticeModule10Demo.java, BinarySearchTree.java, BSTDeleteDemo.java, BSTHeightExperiment.java, BSTInvariantChecker.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 11: AVL Trees and Rotations

Folder: `practice-module-11-avl-trees-rotations`

Related Course Module: Module 4

Topics: height balance, LL, RR, LR, RL rotations, insertion, deletion concept, AVL vs BST

Required Java examples: PracticeModule11Demo.java, AVLTree.java, AVLRotationTraceDemo.java, AVLInvariantChecker.java, AVLvsBSTExperiment.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 12: Splay Trees

Folder: `practice-module-12-splay-trees`

Related Course Module: Module 4

Topics: zig, zig-zig, zig-zag, splaying after access, locality, amortized intuition

Required Java examples: PracticeModule12Demo.java, SplayTree.java, ZigDemo.java, ZigZigDemo.java, ZigZagDemo.java, SplayAccessTraceDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 13: Red-Black Trees and 2-4 Trees

Folder: `practice-module-13-red-black-and-2-4-trees`

Related Course Module: Module 4

Topics: red-black invariants, recoloring, rotations, insertion trace, deletion concepts, 2-4 tree correspondence

Required Java examples: PracticeModule13Demo.java, RedBlackTreeEducational.java, RedBlackInvariantChecker.java, RedBlackInsertionTraceDemo.java, TwoFourTreeTraceDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 14: B-Trees and Multi-Way Search

Folder: `practice-module-14-b-trees-multiway-search`

Related Course Module: Module 4

Topics: multi-way search, B-tree search/insertion, split, median promotion, root/internal split, deletion concept

Required Java examples: PracticeModule14Demo.java, BTreeEducational.java, BTreeSearchDemo.java, BTreeInsertionTraceDemo.java, BTreeSplitDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 15: Java Ordered Collections

Folder: `practice-module-15-java-ordered-collections`

Related Course Module: Module 4

Topics: TreeSet, TreeMap, SortedSet, NavigableSet, NavigableMap, Comparable, Comparator, ordering pitfalls

Required Java examples: PracticeModule15Demo.java, ComparableStudentDemo.java, TreeSetDemo.java, TreeMapDemo.java, OrderingPitfallsDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 16: Binary Heap and Priority Queue

Folder: `practice-module-16-binary-heap-priority-queue`

Related Course Module: Module 5

Topics: binary heap, percolate up/down, buildHeap, decreaseKey, increaseKey, selection, event simulation, d-heap, leftist/skew/binomial heaps

Required Java examples: PracticeModule16Demo.java, BinaryMinHeap.java, BuildHeapDemo.java, SelectionProblemHeapDemo.java, LeftistHeapEducational.java, SkewHeapEducational.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 17: Sorting Algorithms

Folder: `practice-module-17-sorting-algorithms`

Related Course Module: Module 5

Topics: insertion sort, shellsort, heapsort, mergesort, quicksort, quickselect, radix/bucket intro, stability, lower bound intuition

Required Java examples: PracticeModule17Demo.java, InsertionSort.java, ShellSort.java, HeapSort.java, MergeSort.java, QuickSort.java, QuickSelect.java, SortingTimingComparison.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 18: Hash Tables

Folder: `practice-module-18-hash-tables`

Related Course Module: Module 6

Topics: hash functions, separate chaining, linear/quadratic probing, double hashing, lazy deletion, load factor, rehashing, advanced hashing demos

Required Java examples: PracticeModule18Demo.java, SeparateChainingHashTable.java, LinearProbingHashTable.java, QuadraticProbingHashTable.java, RehashingDemo.java, CuckooHashingEducationalDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 19: Amortized Analysis

Folder: `practice-module-19-amortized-analysis`

Related Course Module: Module 6

Topics: dynamic array resizing, table doubling, aggregate/accounting/potential intuition, rehashing, splay/binomial/skew/Fibonacci intuition

Required Java examples: PracticeModule19Demo.java, DynamicArray.java, DynamicArrayResizeTraceDemo.java, AggregateAnalysisDemo.java, FibonacciHeapConceptDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 20: Graph Representations

Folder: `practice-module-20-graph-representations`

Related Course Module: Module 7

Topics: directed/undirected/weighted graphs, adjacency matrix, adjacency list, edge list, degree, sparse/dense tradeoff

Required Java examples: PracticeModule20Demo.java, AdjacencyListGraph.java, AdjacencyMatrixGraph.java, EdgeListGraph.java, SparseDenseGraphComparison.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 21: BFS, DFS, Connected Components, and Topological Sort

Folder: `practice-module-21-bfs-dfs-topological-sort`

Related Course Module: Module 7

Topics: BFS, DFS recursive/iterative, connected components, cycle detection, topological sort by scan and queue

Required Java examples: PracticeModule21Demo.java, BFS.java, DFSRecursive.java, ConnectedComponents.java, TopologicalSortQueue.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 22: Shortest Paths and Dijkstra

Folder: `practice-module-22-shortest-paths-dijkstra`

Related Course Module: Module 8

Topics: unweighted shortest path, Dijkstra with/without priority queue, relaxation, path reconstruction, negative edge limitation, DAG/all-pairs demo

Required Java examples: PracticeModule22Demo.java, UnweightedShortestPathBFS.java, DijkstraWithPriorityQueue.java, RelaxationTraceDemo.java, NegativeEdgeCounterexample.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 23: Disjoint Sets and Union-Find

Folder: `practice-module-23-disjoint-sets-union-find`

Related Course Module: Module 9

Topics: quick-find, quick-union, union by size/rank, path compression, equivalence classes, maze generation

Required Java examples: PracticeModule23Demo.java, QuickFind.java, QuickUnion.java, UnionByRank.java, PathCompressionDemo.java, MazeGenerationDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 24: Minimum Spanning Trees

Folder: `practice-module-24-minimum-spanning-trees`

Related Course Module: Module 9

Topics: Prim, Kruskal, priority queue integration, union-find integration, MST trace, disconnected graph handling

Required Java examples: PracticeModule24Demo.java, PrimMST.java, KruskalMST.java, MSTTraceDemo.java, MSTvsShortestPathDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 25: Algorithm Design Techniques

Folder: `practice-module-25-algorithm-design-techniques`

Related Course Module: Module 10

Topics: greedy, Huffman, bin packing, divide and conquer, selection, dynamic programming, randomized algorithms, backtracking, skip list concept

Required Java examples: PracticeModule25Demo.java, GreedySchedulingDemo.java, HuffmanCodingDemo.java, DynamicProgrammingFibonacciDemo.java, BacktrackingSubsetsDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 26: Advanced Data Structure Selection and Applications

Folder: `practice-module-26-data-structure-selection`

Related Course Module: Module 10

Topics: data structure selection, operation tradeoffs, treap, suffix-array-style string index, k-d tree simplified range search, pairing heap demo

Required Java examples: PracticeModule26Demo.java, DataStructureSelectionCases.java, OperationCostComparison.java, TreapEducationalDemo.java, KDTreeSimplifiedRangeSearchDemo.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.

## Practice Module 27: Final Review Synthesis

Folder: `practice-module-27-final-review-synthesis`

Related Course Module: Module 11

Topics: cumulative tracing, complexity classification, data structure selection, trees/heaps/hashing/sorting/graphs review

Required Java examples: PracticeModule27Demo.java, CumulativeTraceDemo.java, ComplexityClassificationReview.java, FinalExamStylePractice.java.

The module must include runnable demos, trace output, edge cases, complexity comments, and all required Markdown files.
