# Codex Master Prompt

This file expands the one-shot prompt into an implementation plan.

## Completion Standard

This task is not complete if the repository only contains templates.

It is complete only when:

- every `practice-module-00` through `practice-module-27` folder exists,
- every Practice Module contains complete runnable Java code,
- every Practice Module contains required Markdown files,
- every Practice Module compiles independently,
- the root compile script succeeds,
- advanced topics are represented with runnable demos or documented educational simplifications.

## Recommended Build Batches

1. Practice Modules 00-07: Java, ADTs, collections, analysis, recursion, maximum subsequence.
2. Practice Modules 08-15: trees, expression trees, BST, AVL, splay, red-black, B-tree, ordered collections.
3. Practice Modules 16-19: heaps, sorting, hashing, amortized analysis.
4. Practice Modules 20-24: graphs, shortest paths, union-find, MST.
5. Practice Modules 25-27: algorithm design, advanced selection, final review.

If work is too large for one pass, continue batch by batch until complete.

## Teaching Standard

Every Practice Module must support live teaching:

- meaningful printed trace,
- small examples first,
- edge cases,
- complexity discussion,
- invariant checking when relevant,
- student prompts.
