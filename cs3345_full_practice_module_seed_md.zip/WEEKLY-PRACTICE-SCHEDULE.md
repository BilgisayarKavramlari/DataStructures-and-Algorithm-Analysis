# Weekly Practice Schedule

| Week | Course Module | Theory Topic | Practice Status | Practice Modules |
|---|---|---|---|---|
| Week 1 | Module 0 | Setup and orientation | Setup | Practice Module 00, 01 intro |
| Week 2 | Module 1 | Algorithm analysis and foundations | Live practice | Practice Module 01, 02, 03, 04 |
| Week 3 | Module 2 | Recursion and maximum subsequence | Live practice | Practice Module 05, 06, 07 |
| Week 4 | Module 3 | Trees, expression trees, BST | Live practice | Practice Module 08, 09, 10 |
| Week 5 | Module 4 | AVL, splay, red-black, B-trees | Live practice | Practice Module 11, 12, 13, 14, 15 |
| Week 6 | Module 5 | Heaps and sorting | Midterm week; preview/review | Practice Module 16, 17 |
| Week 7 | Module 6 | Hashing and amortized reasoning | Live practice | Practice Module 16, 17, 18, 19 |
| Week 8 | Module 7 | Graph representations, BFS, DFS | Live practice | Practice Module 20, 21 |
| Week 9 | Module 8 | Shortest paths and Dijkstra | Midterm week; preview/review | Practice Module 22 |
| Week 10 | Module 9 | Union-find and MST | Live practice | Practice Module 22, 23, 24 |
| Week 11 | Modules 10-11 | Algorithm design and final review | Review workshop | Practice Module 25, 26, 27 |
