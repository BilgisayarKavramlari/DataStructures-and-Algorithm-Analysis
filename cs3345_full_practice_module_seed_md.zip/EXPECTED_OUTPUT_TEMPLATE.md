# Expected Output for Practice Module XX

## Compile

```bash
javac *.java
```

Expected:

```text
No compiler errors.
```

## Run

```bash
java PracticeModuleXXDemo
```

Representative output:

```text
Practice Module XX: Title
Step 1: ...
Step 2: ...
Complexity summary: ...
```
