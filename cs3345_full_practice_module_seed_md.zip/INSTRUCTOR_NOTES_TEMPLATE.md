# Instructor Notes for Practice Module XX

## Teaching Objective

## Conceptual Bridge

## What to Emphasize

## Common Student Confusions

## Board / Tablet Sketch Suggestions

## Live Coding Suggestions

## Complexity Discussion

## Intentional Simplifications
